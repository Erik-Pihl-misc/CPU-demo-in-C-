#include "cpu.hpp"
int main(void)
{
   cpu::control_unit control_unit1;
   control_unit1.run_with_key_press();
   return 0;
}